module test.db.access {
    requires db.access;
    requires java.sql;
}