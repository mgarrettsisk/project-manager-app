module FX.DB.Sample {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    requires org.jetbrains.annotations;
    requires db.access;

    opens proj_FX;
}