module FX.DB.Sample {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    requires org.jetbrains.annotations;

    opens proj_FX;
}